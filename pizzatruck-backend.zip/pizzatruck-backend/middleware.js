// 1. Records every request in the terminal
const logger = (req, res, next) => {
    const method = req.method;
    const url = req.url;
    const time = new Date().toLocaleTimeString();
    console.log(`[${time}] ${method} request to ${url}`);
    next();
};

// 2. Catches any server errors
const errorHandler = (err, req, res, next) => {
    console.error("SERVER ERROR:", err.stack);
    res.status(500).json({
        success: false,
        message: "Something went wrong on the server!",
        error: process.env.NODE_ENV === 'development' ? err.message : {}
    });
};

// 3. Not Found Handler
const notFound = (req, res, next) => {
    res.status(404).json({
        success: false,
        message: `Route ${req.originalUrl} not found.`
    });
};

module.exports = {
    logger,
    errorHandler,
    notFound
};