const express = require('express');
const router = express.Router();
const db = require('../db');

// Get All Pizzas
router.get('/pizzas', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM pizza');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: "Database error fetching pizzas" });
    }
});

// Get All Pasta
router.get('/pasta', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM pasta');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: "Database error fetching pasta" });
    }
});

// Get All Drinks
router.get('/drinks', async (req, res) => {
    try {
        const [rows] = await db.query('SELECT * FROM drinks');
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: "Database error fetching drinks" });
    }
});

module.exports = router;