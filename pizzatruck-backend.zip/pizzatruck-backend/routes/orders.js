const express = require('express');
const router = express.Router();
const db = require('../db');

router.post('/place-order', async (req, res) => {
    const { user_id, order_items, total_price } = req.body;
    
    try {
        const itemsString = order_items.join(", ");
        
        const query = "INSERT INTO `order` (user_id, order_items, total_price) VALUES (?, ?, ?)";
        const [result] = await db.query(query, [user_id, itemsString, total_price]);
        
        res.status(201).json({ 
            success: true, 
            message: "Order placed successfully", 
            order_id: result.insertId 
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

module.exports = router;