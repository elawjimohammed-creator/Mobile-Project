const express = require('express');
const router = express.Router();
const db = require('../db');

// Register a New User
router.post('/register', async (req, res) => {
    const { fname, lname, DOB, Email, password, phone_number, address } = req.body;
    try {
        const sql = `INSERT INTO user (fname, lname, DOB, Email, password, phone_number, address) 
                     VALUES (?, ?, ?, ?, ?, ?, ?)`;
        const [result] = await db.query(sql, [fname, lname, DOB, Email, password, phone_number, address]);
        res.status(201).json({ message: "User created successfully", userId: result.insertId });
    } catch (err) {
        res.status(400).json({ error: "Registration failed. Email might already exist." });
    }
});

//Log in with an existing
router.post('/login', async (req, res) => {
    const { Email, password } = req.body;
    try {
        const [rows] = await db.query(
            'SELECT * FROM user WHERE Email = ? AND password = ?', 
            [Email, password]
        );
        if (rows.length > 0) {
            res.json({ success: true, user: rows[0] });
        } else {
            res.status(401).json({ success: false, message: "Auth failed" });
        }
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

module.exports = router;