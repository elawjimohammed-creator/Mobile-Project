const express = require('express');
const cors = require('cors');
const orderRoutes = require('./routes/orders');
require('dotenv').config();

// Import routes
const menuRoutes = require('./routes/menu');
const userRoutes = require('./routes/user');

// Import your NEW middleware
const { logger, errorHandler, notFound } = require('./middleware');

const app = express();

app.use(cors());
app.use(express.json());
app.use(logger);

app.use('/api/orders', orderRoutes);
app.use('/api/menu', menuRoutes);
app.use('/api/users', userRoutes);

// 404 Handler
app.use(notFound);

// Error Handler
app.use(errorHandler);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});