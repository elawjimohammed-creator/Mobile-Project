package com.example.pizzatruck

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
