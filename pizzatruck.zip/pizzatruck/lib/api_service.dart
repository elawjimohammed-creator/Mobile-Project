import 'dart:convert';
import 'package:http/http.dart' as http;

class ApiService {
  static Future<Map<String, dynamic>?> login(String email, String password) async {
    try {
      final response = await http.post(
        Uri.parse('http://192.168.1.103:3000/api/users/login'),
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"Email": email, "password": password}),
      ).timeout(Duration(seconds: 3));

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  static Future<bool> register(Map<String, dynamic> userData) async {
  try {
    final response = await http.post(
      Uri.parse('http://192.168.1.103:3000/api/users/register'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(userData),
    ).timeout(const Duration(seconds: 5));

    if (response.statusCode == 201) {
      return true;
    }
    return false;
  } catch (e) {
      print("Register Error: $e");
    return false;
  }
}

static Future<List<dynamic>> getPizza() async {
  try {
    final response = await http.get(Uri.parse('http://192.168.1.103:3000/api/menu/pizzas'))
        .timeout(const Duration(seconds: 5));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return [];
  } catch (e) {
    print("Error fetching menu: $e");
    return [];
  }
}

static Future<List<dynamic>> getPasta() async {
  try {
    final response = await http.get(Uri.parse('http://192.168.1.103:3000/api/menu/pasta'))
        .timeout(const Duration(seconds: 5));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return [];
  } catch (e) {
    print("Error fetching pasta: $e");
    return [];
  }
}

static Future<List<dynamic>> getDrinks() async {
  try {
    final response = await http.get(Uri.parse('http://192.168.1.103:3000/api/menu/drinks'))
        .timeout(const Duration(seconds: 5));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    }
    return [];
  } catch (e) {
    print("Error fetching drinks: $e");
    return [];
  }
}

static Future<bool> submitOrder(Map<String, dynamic> orderData) async {
  try {
    final response = await http.post(Uri.parse('http://192.168.1.103:3000/api/orders/place-order'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(orderData),
    ).timeout(Duration(seconds: 3));

    if (response.statusCode == 201 || response.statusCode == 200) {
      return true;
    } else {
      print("Server Error: ${response.body}");
      return false;
    }
  } catch (e) {
    print("Connection Error: $e");
    return false;
  }
}
}