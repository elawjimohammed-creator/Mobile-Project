class CartItem {
  final String name;
  final String size;
  final double price;

  CartItem({required this.name, required this.size, required this.price});
}

class CartController {
  static List<CartItem> items = [];

  static double get totalPrice => items.fold(0, (sum, item) => sum + item.price);

  static void addItem(String name, String size, double price) {
    items.add(CartItem(name: name, size: size, price: price));
  }

  static void clearCart() {
    items.clear();
  }
}