import 'package:flutter/material.dart';

void main() {
  runApp(PizzaApp());
}

class PizzaApp extends StatelessWidget {
  const PizzaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("Pizza & Pasta Store",
        style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
        backgroundColor: Colors.amber,
        ),
      drawer: Drawer(
        backgroundColor: Colors.black,
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.amber),
              child: Center(
                child: Text(
                  "Menu",
                  style: TextStyle(fontSize: 26, color: Colors.black),
                ),
              ),
            ),
            ListTile(
              title: Text("Pizza List",
              style: TextStyle(color: Colors.white)
              ),
              onTap: () {
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => PizzaMenu()));
              },
            ),
            ListTile(
              title: Text("Pasta List",style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => PastaMenu()));
              },
            ),
            ListTile(
              title: const Text("Drinks",style: TextStyle(color: Colors.white)),
              onTap: () {
                Navigator.push(context,
                    MaterialPageRoute(builder: (context) => DrinksScreen()));
              },
            ),
          ],
        ),
      ),

      body: Center(
        child: Column(
          children: [
            SizedBox(height: 40,),
            Text(
              "Welcome to the Best Pizza & Pasta Store!",
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
            ),
            SizedBox(height: 15),
            Text(
              "We offer delicious handmade pizzas, fresh pasta, and refreshing drinks.\n"
              "Our ingredients are always fresh, and every item is made with love!",
              style: TextStyle(fontSize: 16,color: Colors.white),
            ),
            SizedBox(height: 30,),
            Container(
              width: 200,
              height: 200,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: Colors.green, width: 4),
                image: DecorationImage(
                  image: AssetImage("assets/logo.png"),
                  fit: BoxFit.cover,
                  ),
                ),
              ),
            ],
          ),
       ),
    );
  }
}

class PizzaMenu extends StatelessWidget {
  const PizzaMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: Text("Pizza Categories"),backgroundColor: Colors.amber,centerTitle: true,),
      body: ListView(
        children: [
          ListTile(
            title: Text("Classic Pizza",style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ClassicPizza()));
            },
          ),
          ListTile(
            title: Text("Chicken Pizza",style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => ChickenPizza()));
            },
          ),
          ListTile(
            title: Text("Beef Pizza",style: TextStyle(color: Colors.white)),
            trailing: Icon(Icons.arrow_forward),
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => BeefPizza()));
            },
          ),
        ],
      ),
    );
  }
}

class ClassicPizza extends StatelessWidget {
  const ClassicPizza({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: Text("Classic Pizza"),backgroundColor: Colors.amber,centerTitle: true),
      body: const PizzaList(items: [
        "Margarita\nDescription: Tomato sauce, Mozzarella, Basel, and Oregano.",
        "Four Cheese\nDescritopn: Tomato sauce, Mozzarella, Provolone, Swiss, Parmesan Cheese, and Oregano.",
        "Vegeterian\nDescritopn: Tomato sauce, Mozzarella, Tomatoes, Onions, Green peppers, Fresh mushrooms, Olives, Corn, and Oregano.",
      ]),
    );
  }
}

class ChickenPizza extends StatelessWidget {
  const ChickenPizza({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: Text("Chicken Pizza"),backgroundColor: Colors.amber,centerTitle: true),
      body: const PizzaList(items: [
        "Chicken Ranch\nDescritopn: Chicken, Mozzarella, Green peppers, Olives, Onions, Ranch sauce.",
        "Chicken Pesto\nDescritopn: Pesto sauce, Mozzarella, Chicken, and Fresh mushroom.",
        "Chicken BBQ\nDescritopn: BBQ sauce, Mozzarella, Chicken, Tomatoes, and Fresh mushrooms.",
      ]),
    );
  }
}

class BeefPizza extends StatelessWidget {
  const BeefPizza({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: Text("Beef Pizza"),backgroundColor: Colors.amber,centerTitle: true),
      body: PizzaList(items: [
        "Philly Steak\nDescritopn: Garlic mayo, Mozzarella, Steak, Cheddar, and Provolone cheese.",
        "Spicy Steak\nDescritopn: Garlic mayo, Mozzarella, Steak, Fresh mushroom, and Red hot chilly flakes.",
        "Pepperoni Supreme\nDescritopn: Tomato sauce, Mozzarella, Pepperoni, and Parmesan cheese.",
      ]),
    );
  }
}

class PizzaList extends StatefulWidget {
  final List<String> items;
  const PizzaList({super.key, required this.items});

  @override
  State<PizzaList> createState() => _PizzaListState();
}

class _PizzaListState extends State<PizzaList> {
  final List<String> sizes = ["Small - 5\$", "Medium - 7\$", "Large - 9\$"];
  Map<int, String> selectedSize = {};

  @override
  Widget build(BuildContext context) {
    return Container(
      child: ListView.builder(
        itemCount: widget.items.length,
        itemBuilder: (context, index) {
          return Card(
            margin: EdgeInsets.all(10),
            child: ListTile(
              title: Text(widget.items[index], style: TextStyle(fontSize: 18)),
              subtitle: DropdownButton<String>(
                hint: Text("Select size"),
                value: selectedSize[index],
                items: sizes.map((String size) {
                  return DropdownMenuItem<String>(
                    value: size,
                    child: Text(size),
                  );
                }).toList(),
                onChanged: (value) {
                  setState(() {
                    selectedSize[index] = value!;
                  });
                },
              ),
            ),
          );
        },
      ),
    );
  }
}

class PastaMenu extends StatelessWidget {
  const PastaMenu({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: Text("Pasta List"),centerTitle: true,backgroundColor: Colors.amber,),
      body: const PizzaList(items: [
        "Fettuccine Chicken\nDescritopn: ALfredo sauce, Chicken, and Parmesan cheese.",
        "Penne\nDescritopn: Tomato arrabiata sauce, Basel, and Fresh mushroom.",
        "Fettuccine Pesto\nDescritopn: Creamy pesto sauce, Chicken, pine, and Parmesan cheese.",
      ]),
    );
  }
}

class DrinksScreen extends StatelessWidget {
  const DrinksScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(title: Text("Drinks"),centerTitle: true,backgroundColor: Colors.amber,),
      body: Container(
        child: ListView(
          children: const [
            Card(
              child: ListTile(
                title: Text("Small Water"),
                subtitle: Text("1\$"),
              ),
            ),
            Card(
              child: ListTile(
                title: Text("Soft Drink"),
                subtitle: Text("2\$"),
              ),
            ),
            Card(
              child: ListTile(
                title: Text("Ice Tea"),
                subtitle: Text("2\$"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}