import 'package:flutter/material.dart';
import '../api_service.dart';
import '../cart_controller.dart';
import 'cart_screen.dart';

class PastaMenu extends StatefulWidget {
  const PastaMenu({super.key});

  @override
  State<PastaMenu> createState() => _PastaMenuState();
}

class _PastaMenuState extends State<PastaMenu> {
  Map<int, String> selectedSize = {};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      appBar: AppBar(
        title: const Text(
          "PASTA SELECTION",
          style: TextStyle(
            color: Colors.black, 
            fontWeight: FontWeight.w900, 
            letterSpacing: 2
          ),
        ),
        centerTitle: true,
        backgroundColor: Colors.amber,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.shopping_cart_outlined, color: Colors.black),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const CartScreen()),
              ).then((_) => setState(() {}));
            },
          ),
        ],
      ),
      body: FutureBuilder<List<dynamic>>(
        future: ApiService.getPasta(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator(color: Colors.amber));
          }
          if (snapshot.hasError || !snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(
              child: Text("No pasta available", style: TextStyle(color: Colors.white70)),
            );
          }
          return ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 20),
            itemCount: snapshot.data!.length,
            itemBuilder: (context, index) {
              final item = snapshot.data![index];
              final int id = item['pasta_id']; 
              final Map<String, int> sizePrices = {
                "Small": 7,
                "Medium": 13,
                "Large": 18,
              };
              String displayPrice = selectedSize[id] != null 
                ? "${sizePrices[selectedSize[id]]}\$" 
                : "7\$";
              return Container(
                margin: const EdgeInsets.only(bottom: 20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Colors.white.withOpacity(0.12), 
                      Colors.white.withOpacity(0.05)
                    ],
                  ),
                  border: Border.all(color: Colors.white.withOpacity(0.1)),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(18.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              item['name'].toString().toUpperCase(),
                              style: const TextStyle(
                                color: Colors.white, 
                                fontSize: 19, 
                                fontWeight: FontWeight.bold
                              ),
                            ),
                          ),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.amber.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(10),
                            ),
                            child: Text(
                              displayPrice,
                              style: const TextStyle(
                                color: Colors.amber, 
                                fontSize: 18, 
                                fontWeight: FontWeight.w900
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                      Text(
                        item['description'] ?? "Authentic Italian recipe prepared fresh.",
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.6), 
                          fontSize: 14, 
                          height: 1.4
                        ),
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: Theme(
                              data: Theme.of(context).copyWith(canvasColor: Colors.grey[900]),
                              child: DropdownButtonFormField<String>(
                                decoration: InputDecoration(
                                  contentPadding: const EdgeInsets.symmetric(horizontal: 12),
                                  enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(color: Colors.white24),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(12),
                                    borderSide: const BorderSide(color: Colors.amber),
                                  ),
                                ),
                                hint: const Text("Portion", style: TextStyle(color: Colors.grey, fontSize: 14)),
                                value: selectedSize[id],
                                iconEnabledColor: Colors.amber,
                                dropdownColor: Colors.grey[900],
                                style: const TextStyle(color: Colors.white),
                                items: sizePrices.keys.map((s) => DropdownMenuItem(
                                  value: s, 
                                  child: Text("$s (${sizePrices[s]}\$)"),
                                )).toList(),
                                onChanged: (val) => setState(() => selectedSize[id] = val!),
                              ),
                            ),
                          ),
                          const SizedBox(width: 15),
                          Container(
                            decoration: BoxDecoration(
                              color: Colors.amber,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: IconButton(
                              onPressed: () {
                                if (selectedSize[id] == null) {
                                  ScaffoldMessenger.of(context).showSnackBar(
                                    const SnackBar(
                                      content: Text("Please select a portion size first!"),
                                      backgroundColor: Colors.redAccent,
                                    ),
                                  );
                                  return;
                                }
                                final String size = selectedSize[id]!;
                                final double price = sizePrices[size]!.toDouble();
                                
                                CartController.addItem(item['name'], size, price);

                                ScaffoldMessenger.of(context).showSnackBar(
                                  SnackBar(
                                    backgroundColor: Colors.amber,
                                    duration: const Duration(seconds: 1),
                                    content: Text(
                                      "${item['name']} ($size) added to cart!",
                                      style: const TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                );
                              },
                              icon: const Icon(Icons.add_shopping_cart, color: Colors.black),
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}